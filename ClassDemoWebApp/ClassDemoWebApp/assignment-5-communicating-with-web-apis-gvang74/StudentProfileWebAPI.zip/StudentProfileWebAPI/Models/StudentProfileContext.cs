﻿using Microsoft.EntityFrameworkCore;

namespace StudentProfileWebAPI.Models
{
    public class StudentProfileContext : DbContext
    {
        public StudentProfileContext(DbContextOptions <StudentProfileContext> options) : base(options) 
        { 

        }
        public DbSet<StudentProfile> StudentProfiles { get; set; } = null;
    }
}
