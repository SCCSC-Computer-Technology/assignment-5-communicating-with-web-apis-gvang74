using Microsoft.EntityFrameworkCore;
using StudentProfileWebAPI.Models;
using Microsoft.AspNetCore.HttpLogging; // HttpLoggingFields  // pg 701
using System.Net.Http.Headers; // MediaTypeWithQualityHeaderValue pg 703

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.WebHost.UseUrls("https://localhost:7184/api/StudentProfiles"); // pg 703

builder.Services.AddHttpClient(name: "StudentProfileWebAPI",        // pg 703
    configureClient: options =>
    {
        options.BaseAddress = new Uri("https://localhost:7184/api/StudentProfiles");
        options.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json", 1.0));
    });
builder.Services.AddHttpLogging(options =>          // pg701
{
    options.LoggingFields = HttpLoggingFields.All;
    options.RequestBodyLogLimit = 4096; // defult is 32K
    options.ResponseBodyLogLimit = 4096; // defult is 32k
});
builder.Services.AddControllers();
builder.Services.AddDbContext<StudentProfileContext>(x => x.UseInMemoryDatabase("StudentProfiles"));
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHealthChecks(); //pg 708
//.AddDbContextCheck<>();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseHttpLogging();  // pg701
    app.UseHealthChecks(path: "/howdoyoufeel"); //pg 708
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
