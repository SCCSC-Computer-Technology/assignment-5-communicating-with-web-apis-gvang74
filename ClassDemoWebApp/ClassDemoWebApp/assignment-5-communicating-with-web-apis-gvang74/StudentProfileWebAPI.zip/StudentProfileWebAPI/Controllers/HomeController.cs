﻿using Microsoft.AspNetCore.Mvc;
using StudentProfileWebAPI.Models;

namespace StudentProfileWebAPI.Controllers
{
    public class HomeController : Controller
    {
        private readonly IHttpClientFactory clientFactory;   // pg 703

        public HomeController(ILogger<HomeController> logger,
        StudentProfileContext injectedContext,
        IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            db = injectedContext;
            clientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Customers(string country)  // 704
        {
            string uri;

            if (string.IsNullOrEmpty(country))
            {
                ViewData["Title"] = "All Customers Worldwide";
                uri = "api/students/";
            }
            else
            {
                ViewData["Title"] = $"Students in {country}";
                uri = $"api/customers/?country={country}";
            }

            HttpClient client = clientFactory.CreateClient(
              name: "StudentProfileWebAPI");

            HttpRequestMessage request = new(
              method: HttpMethod.Get, requestUri: uri);

            HttpResponseMessage response = await client.SendAsync(request);

            IEnumerable<Student>? model = await response.Content
              .ReadFromJsonAsync<IEnumerable<Student>>();

            return View(model);
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
